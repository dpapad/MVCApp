package org.mypackage.dal;

/**
 *
 * @author dpa
 */
public interface RepositoryFactory {

    ContactRepository createContactRepository();
}
